**RC9 (15.11.2026):** Current public instructions / Aktuelle öffentliche Anleitung: [docs/INSTALL-RC9.md](docs/INSTALL-RC9.md). Older text below describes historical releases. / Der folgende Text beschreibt historische Releases.

# Installation und Upgrade – v1.0.0-32

### Schnellinstallation (ein Befehl)

Auf dem **Proxmox-VE-Host** als **root**, vorzugsweise über SSH statt über die Web-Shell:

```bash
wget -qO /root/bmv-zfs-manager-quick-install.sh 'https://raw.githubusercontent.com/mbuse79/zfs-manager-pve/main/quick-install.sh' && bash /root/bmv-zfs-manager-quick-install.sh
```

Das [Schnellinstallationsskript](quick-install.sh) lädt die veröffentlichte DEB nach `/tmp`, prüft deren **fest hinterlegte SHA256-Prüfsumme**, führt vor Änderungen einen schreibgeschützten PVE-GUI/API-Kompatibilitätstest durch und installiert per `dpkg -i`. Nur falls `zfs-auto-snapshot` fehlt, wird diese Abhängigkeit ohne allgemeine System-Upgrades oder Paketentfernungen installiert. Auf PVE **9.2.25** läuft die Installation automatisch. Neuere PVE-9-Versionen werden nicht allein wegen ihrer Versionsnummer abgewiesen: Nach erfolgreichem Integrationscheck folgt lediglich eine Warnung mit JA-Bestätigung. Andere Hauptversionen benötigen eine dafür kompatible DEB; die derzeit veröffentlichte DEB unterstützt nur PVE 9.x. Ist eine neuere ZFS-Manager-Paketversion installiert, wird sie beibehalten statt herabgestuft. Unabhängige Backups sind erforderlich. Vor dem Ausführen eines Root-Skripts aus dem Internet den Inhalt prüfen; die Datei von `main` kann sich ändern.

### Manuelle Installation

**Geprüfte Paketrevision (`1.0.0-32+docs2`):** Die exakte DEB (SHA256 `3fa2e7a8777e0c58b80cfadcafdd9b4eabc5da883c35e5e1672b9c3417d2251d`) wurde am **09.11.2026** per APT auf `pve-test` mit Proxmox VE 9.2.25 installiert. Der Maintainer bestätigte `zfsm version`, `zfsm status`, `zfsm check`, `zfsm services` und die Weboberfläche. Der Laufzeitcode ist gegenüber der zuvor getesteten `1.0.0-32` unverändert. Dies ist weder eine Kompatibilitätsfreigabe für andere PVE-Versionen noch eine abgeschlossene Rechteprüfung. Siehe `PACKAGE-STATUS.md`.


**Geprüfte Umgebung:** Proxmox VE 9.2.25. Root-Rechte erforderlich. Die exakte DEB `1.0.0-32+docs2` wurde am 09.11.2026 per APT-Upgrade von `1.0.0-32` installiert; CLI und GUI wurden vom Betreiber erfolgreich bestätigt.

1. Die veröffentlichte `.deb` aus dem [GitHub-Release v1.0.0-32](https://github.com/mbuse79/zfs-manager-pve/releases/tag/v1.0.0-32) herunterladen.
2. Die veröffentlichte SHA256-Prüfsumme kontrollieren. Eine Prüfsumme bestätigt die Dateiintegrität, **nicht allein die Vertrauenswürdigkeit** der Software.
3. Das Paket auf den Proxmox-Host übertragen und aus dem Verzeichnis der `.deb` installieren:

```bash
apt install ./pve-zfs-manager_1.0.0-32+docs2_all.deb
```

Anschließend prüfen:

```bash
dpkg-query -W pve-zfs-manager
zfsm version
zfsm status
zfsm check
zfsm capacity --json
```

Das Proxmox-Webinterface auf Port 8006 öffnen und unter dem Knoten **ZFS Manager** auswählen. Bei Bedarf mit Strg+F5 aktualisieren.

### Falls die Web-Shell unterbrochen wird

Beim Nachladen der Proxmox-Oberfläche kann die Browser-Shell getrennt werden. Zuerst den Paketstatus prüfen. Alternativ lässt sich ein vertrauenswürdiges lokales Paket mit einer eigenen systemd-Unit installieren:

```bash
systemd-run --unit=zfsm32-install --collect /usr/bin/apt-get install -y /root/pve-zfs-manager_1.0.0-32+docs2_all.deb
journalctl -u zfsm32-install -n 50 --no-pager
```

### Vor dem Produktiveinsatz

Unabhängige Backups und einen Wiederherstellungstest einplanen. Lösch- und Rollback-Aktionen über mehrere Datasets sind nicht atomar. Für die Integration werden vorhandene Proxmox-GUI-/API-Dateien angebunden; nach Updates können Reparaturen erforderlich sein. Nicht getestete Versionen gelten nicht automatisch als kompatibel.

### Deinstallation

```bash
apt remove pve-zfs-manager
```

Vorhandene Sicherungen und Konfigurationsdateien prüfen. Nicht manuell in Proxmox-GUI-Dateien löschen. Zur Diagnose dienen `zfsm check`, `zfsm backups` und `zfsm logs`.

> **Hinweis / note (2026-11-10):** The intended release asset is `1.0.0-32+docs2` (SHA256 above), tested on `pve-test` on 2026-11-09. The original `1.0.0-32` remains a separate historical reference with a different checksum. / Das vorgesehene Release-Paket ist `1.0.0-32+docs2`; nicht mit dem älteren Paket verwechseln.
