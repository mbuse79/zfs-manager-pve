**RC9 (15.11.2026):** Current public instructions / Aktuelle öffentliche Anleitung: [docs/INSTALL-RC9.md](docs/INSTALL-RC9.md). Older text below describes historical releases. / Der folgende Text beschreibt historische Releases.

# Installation and upgrade – v1.0.0-32

### One-command quick installation

Run on a **Proxmox VE host as root**, preferably from SSH instead of the web shell:

```bash
wget -qO /root/bmv-zfs-manager-quick-install.sh 'https://raw.githubusercontent.com/mbuse79/zfs-manager-pve/main/quick-install.sh' && bash /root/bmv-zfs-manager-quick-install.sh
```

The [quick installer](quick-install.sh) downloads the published DEB to `/tmp`, verifies an **embedded SHA256 checksum**, performs a read-only GUI/API compatibility precheck and installs via `dpkg -i`. It installs the missing `zfs-auto-snapshot` dependency only if necessary, without general system upgrades or package removals. Installation is automatic on tested **PVE 9.2.25**. Newer PVE 9.x releases are not blocked merely by version: after a successful structural check the installer requires one explicit warning confirmation. Other major versions need a separately compatible package; the current DEB supports PVE 9.x only. If a newer ZFS Manager package is already installed, it is kept without downgrading. Keep independent backups. Review remote root scripts before running them; the script downloaded from `main` can change.

### Manual installation

**Verified packaging revision (`1.0.0-32+docs2`):** The exact DEB (SHA256 `3fa2e7a8777e0c58b80cfadcafdd9b4eabc5da883c35e5e1672b9c3417d2251d`) was installed via APT on `pve-test` (Proxmox VE 9.2.25) on **2026-11-09**. The maintainer confirmed `zfsm version`, `zfsm status`, `zfsm check`, `zfsm services` and the web interface. Its runtime code matches the previously tested `1.0.0-32`; this does not establish compatibility with other PVE versions or complete the rights review. See `PACKAGE-STATUS.md`.


**Validated final environment:** Proxmox VE 9.2.25. Root access is required. The exact `1.0.0-32+docs2` Debian package was installed as an APT upgrade from `1.0.0-32` on 2026-11-09; CLI and GUI were reported working by the test host owner.

1. Download the released `.deb` from [GitHub Releases](https://github.com/mbuse79/zfs-manager-pve/releases/tag/v1.0.0-32).
2. Verify the published SHA256 checksum. A checksum validates file integrity, **not** software trust or authenticity by itself.
3. Copy the .deb to the target Proxmox host and run:

```bash
apt install ./pve-zfs-manager_1.0.0-32+docs2_all.deb
```

Check the installation:

```bash
dpkg-query -W pve-zfs-manager
zfsm version
zfsm status
zfsm check
zfsm capacity --json
```

Visit the Proxmox VE interface on port 8006 and select **ZFS Manager** under the node. Refresh (Ctrl+F5) if needed.

### If the web shell disconnects

A Proxmox GUI refresh may interrupt an active browser shell. First check whether the package install completed. An optional alternative for a trusted local DEB is:

```bash
systemd-run --unit=zfsm32-install --collect /usr/bin/apt-get install -y /root/pve-zfs-manager_1.0.0-32+docs2_all.deb
journalctl -u zfsm32-install -n 50 --no-pager
```

### Before production use

Keep independent backups and perform a recovery test. Destructive snapshot operations are not atomic across datasets. The software integrates into Proxmox's existing GUI/API files and may need repair after upstream changes. Do not assume compatibility with untested releases.

### Uninstall

```bash
apt remove pve-zfs-manager
```

Inspect retained backup and policy files rather than deleting Proxmox GUI files manually. Diagnostic commands include `zfsm check`, `zfsm backups` and `zfsm logs`.

> **Hinweis / note (2026-11-10):** The intended release asset is `1.0.0-32+docs2` (SHA256 above), tested on `pve-test` on 2026-11-09. The original `1.0.0-32` remains a separate historical reference with a different checksum. / Das vorgesehene Release-Paket ist `1.0.0-32+docs2`; nicht mit dem älteren Paket verwechseln.
