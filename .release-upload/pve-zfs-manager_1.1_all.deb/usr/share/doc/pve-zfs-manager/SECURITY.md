# Security policy / Sicherheit

## Scope

Version 1.1 supports structurally compatible PVE 9.x integrations. The operator
confirmed its Fix2 predecessor's real cluster installation on PVE 9.2.26 and 9.2.21.
The exact 1.1 package was rebuilt for release identification and automatically
tested; this is not a claim of a new 1.1 real-host test or universal future support.
This is independent community software, not an official Proxmox product.

## Reporting a vulnerability

**Do not post exploits, credentials or sensitive system details in public GitHub issues.** Contact the maintainers privately at **[bumavory@buse.rocks](mailto:bumavory@buse.rocks)**. The maintainer reported a successful email function test on 2026-11-09; separate external sender/response evidence has not been reviewed in this audit. GitHub Private Vulnerability Reporting was enabled on 2026-11-10, as confirmed by the maintainer using the GitHub API. Use the repository Security tab for confidential reports.

## Operational risks

- Snapshot deletion and rollback can lead to permanent data loss.
- Operations spanning multiple datasets/disks are not atomic.
- Keep independent off-host backups and test recovery.
- Restrict management access to authorized Proxmox administrators. Do not expose the Proxmox management interface directly to the public internet.
- Verify distribution origin and release hashes before installing packages with root privileges.

## Deutsch

Sicherheitslücken nicht mit Exploit-Details in öffentlichen Issues melden. Meldungen bitte vertraulich an **bumavory@buse.rocks** senden. Der Maintainer meldete am 09.11.2026 einen erfolgreichen E-Mail-Funktionstest; ein separater externer Zustell- und Antwortnachweis wurde bei dieser Prüfung nicht eingesehen. Destruktive Snapshot-Aktionen nur mit unabhängigen Sicherungen und auf geprüften Systemen durchführen.
